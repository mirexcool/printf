/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yyefimov <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/26 12:42:51 by yyefimov          #+#    #+#             */
/*   Updated: 2017/02/11 20:08:38 by yyefimov         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "printf.h"
#include <stdio.h>

int	main(void)
{
	char	*format = "%.p, %.p";
//	char	*format = "% 10.5d";

	long long a = 4242;
	char *str = "this";
	char s = 42;


	write(1, "MAN  = --->", 11);
	printf("| %d |", printf("111%s333%s555%saaa%sccc", "222", "444", "666", "bbb"));
	printf("<---\n");
	write(1, "MY   = --->", 11);
	printf("| %d |", ft_printf("111%s333%s555%sccc%sccc", "222", "444", "666", "bbb"));
	printf("<---\n");
//	ft_printf("@moulitest: %#.x %#.0x", 0, 0);
}
